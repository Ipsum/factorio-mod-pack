BLUE_BACKGROUND = "__base__/graphics/icons/signal/shape_square.png"

data:extend({
  {
    type = "item-subgroup",
    name = "couple-signals",
    group = "signals",
    order = "g"
  },
  {
    type = "virtual-signal",
    name = "signal-couple",
    icons =
    {
      {icon = BLUE_BACKGROUND},
      {icon = "__Automatic_Coupler_016__/graphics/signal/couple.png"}
    },
    icon_size = 32,
    subgroup = "couple-signals",
    order = "a-a"
  },
  {
    type = "virtual-signal",
    name = "signal-uncouple",
    icons =
    {
      {icon = BLUE_BACKGROUND},
      {icon = "__Automatic_Coupler_016__/graphics/signal/uncouple.png"}
    },
    icon_size = 32,
    subgroup = "couple-signals",
    order = "a-b"
  }
})