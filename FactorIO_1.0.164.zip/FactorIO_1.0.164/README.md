# Factor-I/O
Adds several sensors which allow for automatic monitoring of things not normally available to the circuit network, thus enabling more advanced automation.
-----------------
Primary Features:
Adds sensor for: Number of empty slots in an inventory
Adds sensor for: Fluid temperature
Adds sensor for: Time of day
Adds sensor for: Research progress
Adds a timer which pulses periodically (a la 555)
Adds sensor for: Number of near enemy units (biters, spitters, etc)
Adds sensor for: Power production
Adds sensor for: Power consumption
Adds sensor for: Number of logistic robots
Adds sensor for: Number of construction robots


Secondary Features:
