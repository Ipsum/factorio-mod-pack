--[[

data:extend({
        {
            type = "bool-setting",
            name = "add-larger-warehouses",
            setting_type = "startup",
            default_value = true,
            order = "r",
        },
        {
            type = "bool-setting",
            name = "add-unloader",
            setting_type = "startup",
            default_value = true,
            order = "r",
        },
})
--]]