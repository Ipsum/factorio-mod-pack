require("prototypes.base")
require("prototypes.tech")
require("prototypes.recipes")