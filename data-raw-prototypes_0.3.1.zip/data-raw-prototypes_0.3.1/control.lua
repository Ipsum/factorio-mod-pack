--[[
save loaded data in global because loadstring is slow
if mods config changes then dump the cache and start again
supply interface so all mods can use this cache and functions
]]--
local chunk_suffix = "__"
remote.add_interface("data-raw", {
    prototype = function(type_name, prototype_name)
        return data_raw(type_name, prototype_name)
    end,
    prototypes_of_type = function(type_name)
        return data_raw_all(type_name)
    end,
    prototypes_list = function ()
        return data_list()
    end
})

function get_chunked_string(name)
    local string = ""
    if game then
        local i = 1
        while game.entity_prototypes[name .. chunk_suffix .. i] do
            string = string..game.entity_prototypes[name .. chunk_suffix .. i].order
            i = i + 1
        end
    end
    return string
end

function get_chunked_data(name)
    local string = get_chunked_string(name)
    if #string > 0 then
        return loadstring(string)()
    end
    return nil
end

-- Split text into a list consisting of the strings in text,
-- separated by strings matching delimiter (which may be a pattern).
-- example: strsplit("Anna, Bob, Charlie,Dolores", ",%s*")
function strsplit(inputstr, sep)
    if sep == nil then
        sep = "%s"
    end
    local t={} ; i=1
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        t[i] = str
        i = i + 1
    end
    return t
end

function data_raw(type_name, prototype_name)
    --game.print("data_raw: ".. type_name .. " " .. prototype_name)
    if not (type_name and prototype_name) then return end
    if not global.raw then
        global.raw = {}
    end
    if not global.raw[type_name] then
        global.raw[type_name] = {}
    end
    if not global.raw[type_name][prototype_name] then -- only do this once
        global.raw[type_name][prototype_name] = get_chunked_data("data_raw_"..type_name.."_"..prototype_name)
    end
    return global.raw[type_name][prototype_name]
end

function data_raw_all(type_name)
    if not (type_name) then return end
    if not global.raw then
        global.raw = {}
    end
    if not global.raw[type_name] then
        global.raw[type_name] = {}
    end
    if(data_list(type_name) and global.list[type_name]) then
        for _, prototype_name in ipairs(global.list[type_name]) do
            data_raw(type_name, prototype_name)
        end
    end
    return global.raw[type_name]
end

function data_list()
    if not global.list then
    global.list = {}
    local string = get_chunked_data("data_list")
    for _, typestring in pairs(strsplit(string, "|")) do
        local type_prototypes = strsplit(typestring, ".")
        if #type_prototypes == 2 then
            local type = type_prototypes[1]
            local prototypes_string = type_prototypes[2]
            global.list[type] = {}
            for _, prototype in pairs(strsplit(prototypes_string, ",")) do
                table.insert(global.list[type], prototype)
            end
        end
    end
    end
    return global.list
end

script.on_configuration_changed(function()
    global.raw = {}
    global.list = nil
end)
