
-- data_raw_shortlist builds up a list of prototypes and properties to include in the data compile phase
-- IMPORTANT: use data_raw_require to add to the shortlist
data_raw_shortlist = {}

-- data_raw_chunks lists all the prototypes that were generated to store chunked data during data_raw_compile
-- this is so they can easily be removed if data_raw_compile is called again, so they get replaced with updated data
data_raw_chunks = {}

-- data_raw_compile_last_call is initially set to "data-raw-prototypes"
-- in data.lua other mods can change this to their mod name signifying that thier mod is later in the load order
-- AND that their mod will call data_raw_compile() at the end of their data-final-fixes
-- IF data_raw_compile_last_call is still set to their mod name
-- in this way only the last loading mod calls data_raw_compile() and the compile does not need to be repeatedly done and undone
data_raw_compile_last_call = "data-raw-prototypes"

function data_raw_require(prototype_type, prototype_name, property_name)
    -- equivalent to data.raw[prototype_type][prototype_name][property_name]
    -- prototype_type must be string
    -- prototype_name can be a string, "*" , or an array of prototype_names
    -- property_name can be a string or an array of property_names
    -- NOTE: some things may get stored as data_raw_shortlist[prototype_type]["*"][property_name]

    if not data_raw_shortlist then data_raw_shortlist = {} end

    if not (prototype_type and prototype_name and property_name) then return end

    if type(prototype_name) ~= "table" then
        prototype_name = {prototype_name}
    end
    if type(property_name) ~= "table" then
        property_name = {property_name}
    end
    data_raw_shortlist[prototype_type] = data_raw_shortlist[prototype_type] or {}
    for _, prot_name in pairs(prototype_name) do
        data_raw_shortlist[prototype_type][prot_name] = data_raw_shortlist[prototype_type][prot_name] or {}
        for _, prop_name in pairs(property_name) do
            data_raw_shortlist[prototype_type][prot_name][prop_name] = prop_name
        end
    end
end

function data_raw_compile()
    -- compile the data
    -- if the data has already been compiled then remove the existing data and start again.
    -- if a mod has data-raw-prototypes as a dependency it can call

    -- remove any existing data_raw_chunks
    for _, name in pairs(data_raw_chunks) do
        data.raw["flying-text"][name] = nil
    end
    data_raw_chunks = {}

    local function data_raw_save_chunk (name, string)
        data:extend({{
          type = "flying-text",
          name = name,
          time_to_live = 0,
          speed = 1,
          order = string
        }})
        data_raw_chunks[name] = name
    end

    local function data_raw_chunkify(string)
        local chunkSize = 200
        local s = {}
        for i=1, #string, chunkSize do
            s[#s+1] = string:sub(i,i+chunkSize - 1)
        end
        return s
    end

    local function data_raw_save_string (name, string)
        local chunks = data_raw_chunkify(string)
        for i, chunk in ipairs(chunks) do
            data_raw_save_chunk(name.."__"..i, chunk)
        end
    end

    -- make a packed list of prototypes by type, csv style format
    local prototype_list = "";
    for type_name, prototypes in pairs(data.raw) do
        if prototype_list ~= "" then
            prototype_list = prototype_list .. "|"
        end
        prototype_list = prototype_list .. type_name .. "."
        local first = true
        for proto_name, prototype in pairs(prototypes) do
            if not first then
                prototype_list = prototype_list .. ","
            else
                first = false
            end
            prototype_list = prototype_list .. proto_name
        end
    end
    data_raw_save_string("data_list", serpent.dump(prototype_list))

    local shortlist = table.deepcopy(data_raw_shortlist)
    --log("shortlist ")
    --log( serpent.block( shortlist, {comment = false, numformat = '%1.8g' } ) )

    -- inflate "*" from shortlist to specifiy prototypes
    for type_name, type_data in pairs(shortlist) do
        for proto_name, proto_data in pairs(type_data) do
            if proto_name == "*" then
                for _, prototype in pairs(data.raw[type_name]) do
                    shortlist[type_name][prototype.name] = shortlist[type_name][prototype.name] or {}
                    for prop_name in pairs(proto_data) do
                        shortlist[type_name][prototype.name][prop_name] = prop_name
                    end
                end
                shortlist[type_name][proto_name] = nil
            end
        end
    end
    --log("shortlist inflated")
    --log( serpent.block( shortlist, {comment = false, numformat = '%1.8g' } ) )

    -- save only the required prototypes
    -- with only the required properties
    for type_name, type_data in pairs(shortlist) do
        if data.raw[type_name] and type_name ~= "flying-text" then
            for proto_name, proto_data in pairs(type_data) do
                if data.raw[type_name][proto_name] then
                    local micro = {
                      name = proto_name,
                      type = type_name
                    }
                    for prop_name in pairs(proto_data) do
                        -- data.raw[type_name][proto_name][prop_name] can be nil
                        micro[prop_name] = data.raw[type_name][proto_name][prop_name]
                    end
                    data_raw_save_string("data_raw_"..type_name.."_"..proto_name, serpent.dump(micro))
                    --log( serpent.block( micro, {comment = false, numformat = '%1.8g' } ) )
                end
            end
        end
    end

end
