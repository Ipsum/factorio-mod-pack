# factorio-mod-data-raw-types
A modding utility to access raw prototype data from data.raw within control.lua. Prototypes are only loaded as required, cached to the save game for as long as the mods state is unchanged, and the cache is shared across all mods.

## Only required data is stored and returned
You need to specify what data should be stored from data.lua using data_raw_require(). Make sure to only require what you absolutely need and cannot get from http://lua-api.factorio.com/0.15.9/LuaGameScript.html#LuaGameScript.entity_prototypes Every prototype and every property takes a serious toll on game launch speed, map loading speed, and GUI responsiveness. Requiring too much data with other mods installed may cause the game to exceed the 60000+ entities of a type limitation and fail to start up.

## Require prototype properties to be stored
```lua
-- in data.lua
data_raw_require(prototype_type, prototype_name, property_name)
--eg:
data_raw_require("car", "tank", "turn_speed")
-- the turn_speed will be saved from data.raw.car.tank

data_raw_require("car", {"tank", "car"}, "turn_speed")
-- the turn_speed will be saved from data.raw.car.tank, and data.raw.car.car.

data_raw_require("car", "*", "turn_speed")
-- the turn_speed will be saved from data.raw.car.car, data.raw.car.tank, and any other car-type vehicles added by other mods

data_raw_require("car", "*", {"turn_speed", "turret"})
-- the turn_speed and turret data will be saved from data.raw.car.car, data.raw.car.tank, and any other car-type vehicles added by other mods
```

## Access a raw prototype
```lua
remote.call("data-raw", "type", "car", "tank")
-- returns properties from the raw prototype of data.raw.car.tank
-- replace "car" with the desired prototype type and "tank" with the desired prototype name.
-- only prototypes and properties that were required by data_raw_require() will be available
```

## Access all prototypes of a type
```lua
remote.call("data-raw", "prototypes_of_type", "car")
-- returns a prototype dictionary with entries for all the prototypes of a type
-- only prototypes and properties that were required by data_raw_require() will be available
-- other prototypes of that type that were not required will be empty {}
-- eg: {car = {}, tank = {turret_speed = 0.1}}
```

## Access a list of all prototype types and prototype names
```lua
remote.call("data-raw", "prototypes_list")
-- returns a dictionary of prototype types, each containing a list of prototype names of that type -- e.g: {car = {"car", "tank", ...}, gun = {"shotgun", ...}, ...}
```

## Troubleshooting
The 'game' variable must have loaded in order to access the prototypes, see the http://lua-api.factorio.com/latest/Data-Lifecycle.html for more details.

Avoid using data-final-fixes.lua to alter prototypes, use data-updates.lua instead where possible.

If you do need to change things in data-final-fixes.lua then in data.lua set data_raw_compile_last_call to your mod name, then if at the end of data-final-fixes data_raw_compile_last_call is still your mod name then call data_raw_compile() to recompile with all your changes.
```lua
-- data.lua
data_raw_compile_last_call = "my-mod-name"
```
```lua
-- end of data-final-fixes.lua
if data_raw_compile_last_call == "my-mod-name" then
    data_raw_compile()
end
```
