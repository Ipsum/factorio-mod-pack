data:extend({





-- breacking force 

  {
    type = "technology",
    name = "braking-force-b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.1
      }
    },
    prerequisites = {"railway"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 5},
        {"science-pack-2", 1},
       
        {"military-science-pack", 50},
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-a"
  },


  {
    type = "technology",
    name = "braking-force-1b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.1
      }
    },
    prerequisites = {"railway"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 3},
        {"science-pack-2", 2},
        {"science-pack-3", 1},
        {"military-science-pack", 100},
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-a"
  },



  {
    type = "technology",
    name = "braking-force-2b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"braking-force-1"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 11},
        {"science-pack-2", 7},
        {"military-science-pack", 150},
        {"science-pack-3", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-b"
  },




  {
    type = "technology",
    name = "braking-force-3b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"braking-force-2", "logistics-3"},
    unit =
    {
      count = 250,
      ingredients =
      {
        {"science-pack-1", 10},
        {"science-pack-2", 5},
        {"science-pack-3", 5},
        {"military-science-pack", 170},
        {"production-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-c"
  },


  {
    type = "technology",
    name = "braking-force-4b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"braking-force-3"},
    unit =
    {
      count = 350,
      ingredients =
      {
        {"science-pack-1", 13},
        {"science-pack-2", 9},
        {"science-pack-3", 9},
         {"military-science-pack", 180},
        {"production-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-d"
  },



  {
    type = "technology",
    name = "braking-force-5b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.2
      }
    },
    prerequisites = {"braking-force-4"},
    unit =
    {
      count = 450,
      ingredients =
      {
        {"science-pack-1", 13},
        {"science-pack-2", 13},
        {"science-pack-3", 13},
         {"military-science-pack", 200},
        {"production-science-pack", 5}
      },
      time = 35
    },
    upgrade = true,
    order = "b-f-e"
  },




  {
    type = "technology",
    name = "braking-force-6b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.25
      }
    },
    prerequisites = {"braking-force-5"},
    unit =
    {
      count = 550,
      ingredients =
      {
        {"science-pack-1", 19},
        {"science-pack-2", 19},
        {"science-pack-3", 19},
        {"military-science-pack", 200},
        {"production-science-pack", 11},
        {"high-tech-science-pack", 1}
      },
      time = 45
    },
    upgrade = true,
    order = "b-f-f"
  },




  {
    type = "technology",
    name = "braking-force-7b",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.25
      }
    },
    prerequisites = {"braking-force-6"},
    unit =
    {
      count = 650,
      ingredients =
      {
        {"science-pack-1", 21},
        {"science-pack-2", 21},
        {"science-pack-3", 21},
        {"production-science-pack", 200},
        {"high-tech-science-pack", 81}
      },
      time = 60
    },
    upgrade = true,
    order = "b-f-g"
  },


  {
    type = "technology",
    name = "braking-force-8",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.1
      }
    },
    prerequisites = {"braking-force-7"},
    unit =
    {
    count_formula = "(L+2)*L*10",
    ingredients =
    {
      {"science-pack-1", 15},
      {"science-pack-2", 15},
      {"science-pack-3", 15},
      {"production-science-pack", 45},
      {"high-tech-science-pack", 15},
      {"space-science-pack", 15}
    },
      time = 10
    },
  max_level = "infinite",
    upgrade = true,
    order = "b-f-a"
  },












  --power 








--[[




  {
    type = "technology",
    name = "train-power-b",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.1
      }
    },
    prerequisites = {"railway"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
       
        {"military-science-pack", 50},
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-a"
  },


  {
    type = "technology",
    name = "train-power-1",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.1
      }
    },
    prerequisites = {"railway"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 3},
        {"science-pack-2", 2},
        {"science-pack-3", 1},
        {"military-science-pack", 150},
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-a"
  },



  {
    type = "technology",
    name = "train-power-2",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-1"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 7},
        {"science-pack-2", 5},
        {"military-science-pack", 250},
        {"science-pack-3", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-b"
  },




  {
    type = "technology",
    name = "train-power-3",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-2", "logistics-3"},
    unit =
    {
      count = 250,
      ingredients =
      {
        {"science-pack-1", 21},
        {"science-pack-2", 15},
        {"science-pack-3", 10},
         {"military-science-pack", 350},
        {"production-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-c"
  },


  {
    type = "technology",
    name = "train-power-4",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-3"},
    unit =
    {
      count = 350,
      ingredients =
      {
        {"science-pack-1", 21},
        {"science-pack-2", 21},
        {"science-pack-3", 11},
         {"military-science-pack", 450},
        {"production-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "b-f-d"
  },



  {
    type = "technology",
    name = "train-power-5",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-4"},
    unit =
    {
      count = 450,
      ingredients =
      {
        {"science-pack-1", 21},
        {"science-pack-2", 21},
        {"science-pack-3", 21},
         {"military-science-pack", 550},
        {"production-science-pack", 11}
      },
      time = 35
    },
    upgrade = true,
    order = "b-f-e"
  },




  {
    type = "technology",
    name = "train-power-6",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-5"},
    unit =
    {
      count = 550,
      ingredients =
      {
        {"science-pack-1", 31},
        {"science-pack-2", 31},
        {"science-pack-3", 31},
        {"military-science-pack", 650},
        {"production-science-pack", 21},
        {"high-tech-science-pack", 11}
      },
      time = 45
    },
    upgrade = true,
    order = "b-f-f"
  },




  {
    type = "technology",
    name = "train-power-7",
    icon_size = 128,
    icon = "__train_tech___/graphics/train-power.png",
    effects =
    {
      {
        type = "max_power-bonus",
        modifier = 0.15
      }
    },
    prerequisites = {"train-power-6"},
    unit =
    {
      count = 650,
      ingredients =
      {
        {"science-pack-1", 31},
        {"science-pack-2", 31},
        {"science-pack-3", 31},
        {"production-science-pack", 1},
        {"military-science-pack", 850},
        {"high-tech-science-pack", 31}
      },
      time = 60
    },
    upgrade = true,
    order = "b-f-g"
  }




--]]


})



