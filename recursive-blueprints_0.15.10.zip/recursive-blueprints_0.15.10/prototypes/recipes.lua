data:extend{
  {
    type = "recipe",
    name = "blueprint-deployer",
    enabled = false,
    ingredients =
    {
      {"steel-chest", 1},
      {"electronic-circuit", 1}
    },
    result = "blueprint-deployer"
  },
}
