-- hovercraft
-- prototypes.missilecraft


-- Missile-craft
local missilecraft_entity = table.deepcopy(data.raw["car"]["hovercraft-entity"])
local updates = {
	name = "missilecraft",
	minable = {
        mining_time = 3,
        result = "missilecraft"
    },
	guns = {
        "vehicle-missile-turret"
    },
	turret_animation =
    {
      layers =
      {
        {
          filename = "__Hovercraft__/graphics/vehicle-rocket-sheet2.png",
          line_length = 16,
          width = 88,
          height = 80,
          frame_count = 1,
          axially_symmetrical = false,
          direction_count = 64,
          shift = {.05,-.85},
          scale = 0.5,
        }
      }
    },
    turret_rotation_speed = 0.40 / 60,
    turret_return_timeout = 300,
}

for k,v in pairs(updates) do
	missilecraft_entity[k] = updates[k]
end

-- Missile Turret
missile_turret = {
  attack_parameters = {
	ammo_category = "rocket",
	cooldown = 50,
	movement_slow_down_factor = 0.8,
	projectile_center = {
	  -0.17000000000000002,
	  0
	},
	projectile_creation_distance = 0.6,
	range = 30,
	sound = {
	  {
		filename = "__base__/sound/fight/rocket-launcher.ogg",
		volume = 0.7
	  }
	},
	type = "projectile"
  },
  flags = {
	"goes-to-main-inventory","hidden"
  },
  icon = "__Hovercraft__/graphics/icons/missile-turret.png",
  icon_size = 32,
  name = "vehicle-missile-turret",
  order = "d[rocket-launcher]",
  stack_size = 1,
  subgroup = "gun",
  type = "gun"
}


-- Item
local missilecraft_item = {
	type = "item",
	name = "missilecraft",
	icon = "__Hovercraft__/graphics/icons/missile_small.png",
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "transport2",
	order = "b[personal-transport]-d",
	stack_size = 1,
	place_result = "missilecraft"	
}


-- Tech
local missilecraft_tech = {
	type = "technology",
	name = "missilecraft",
	icon = "__Hovercraft__/graphics/icons/missile-tech.png",
	icon_size = 128,
	effects =
	{
		{type = "unlock-recipe", recipe = "missilecraft"},
	},
	prerequisites = {"hovercraft-tech","rocket-speed-3","military-3"},
	unit =
	{
		count = 200,
		ingredients =
		{
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1},
			{"military-science-pack", 1},
		},
		time = 60
	},
	order = "a"
}


-- Recipe
local missilecraft_recipe = {
	type = "recipe",
	name = "missilecraft",
	energy_required = 10,
	enabled = false,
	ingredients =
	{
        {
          "hovercraft-item",
          1
        },
        {
          "gun-turret",
          1
        },
        {
          "rocket-launcher",
         8
        }
      },
	result = "missilecraft",
	result_count = 1
}


data:extend({
	missilecraft_tech,
	missilecraft_recipe,
	missilecraft_item,
	missilecraft_entity,
	missile_turret
})