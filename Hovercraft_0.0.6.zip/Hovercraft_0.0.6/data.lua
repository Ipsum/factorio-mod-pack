-- Hovercraft
-- data.lua

require("prototypes.hovercraft")
require("prototypes.swimming")
require("prototypes.missilecraft")