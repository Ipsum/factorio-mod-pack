-- Hovercraft
-- control.lua


local isWaterTile = {["water"]=true,["deepwater"]=true}

-- check for other mods that make water effects
-- push all into on_load?
local makeEffects = true
local function modCheck()
	if remote.interfaces["CanalBuilder"] and remote.interfaces["CanalBuilder"]["exists"] then
		makeEffects = false
	else
		makeEffects = true
	end
end


-- aesthetic ripple
local function make_ripple(player)
	local p = player.position
	local surface = player.surface
	if isWaterTile[surface.get_tile(p).name] then
		local r = 2.5
		local area = {{p.x - r, p.y - r}, {p.x + r, p.y + r}}
		if surface.count_tiles_filtered{area = area, name = "water", limit = 25} +
			surface.count_tiles_filtered{area = area, name = "deepwater", limit = 25} >= 25
		then			-- only ripple if in large water patch
			if player.driving then
			surface.create_entity{name = "water-ripple" .. math.random(1, 4) .. "-smoke", position={p.x,p.y+.75}}
			else
			surface.create_entity{name = "water-ripple" .. math.random(1, 4) .. "-smoke", position={p.x,p.y}}
			end
		end
	end
end


-- aesthetic splash
local function make_splash(player)
	if isWaterTile[player.surface.get_tile(player.position).name] then
		player.surface.create_entity{name = "water-splash-smoke", position = player.position}
	end
end


-- when moving about in a hovercraft
script.on_event(defines.events.on_player_changed_position, function(e)
	local player = game.players[e.player_index]
	if player.character then
		if makeEffects then
			make_ripple(player)
			make_splash(player)
		end
	end
end)


-- now and then create smoke, ripple
local function	tickHandler(e)
	local eTick = e.tick
	if eTick % 7==2 then
		for _,player in pairs(game.connected_players) do
			if player.character and player.driving then
				if player.vehicle.name=="hovercraft-entity" then
					player.surface.create_trivial_smoke{name="hover-smoke", position=player.position}
				end
			end
		end
	end
	if eTick % 120 == 4 then
		for _,player in pairs(game.connected_players) do
			if player.character and makeEffects then
				make_ripple(player)
			end
		end
	end
end
script.on_event(defines.events.on_tick,tickHandler)

script.on_load(modCheck)
