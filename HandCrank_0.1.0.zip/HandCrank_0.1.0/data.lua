require('prototypes.item.hand-crank')
require('prototypes.entity.hand-crank')
require('prototypes.recipe.hand-crank')
