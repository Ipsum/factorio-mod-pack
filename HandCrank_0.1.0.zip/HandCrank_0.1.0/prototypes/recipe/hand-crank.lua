data:extend{
	{
		type = 'recipe',
		name = 'hand-crank',
		category = 'crafting',
		subgroup = 'energy',
		energy_required = '6',
		ingredients = {
			{'iron-gear-wheel', 4},
			{'copper-cable', 2}
		},
		result = 'hand-crank'
	}
}
