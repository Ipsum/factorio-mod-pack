local off_grid_types = {"explosion", "smoke", "particle", "projectile", "fire", "item-entity"}

for _, off_grid_type in ipairs(off_grid_types) do
	for prototype_name,prototype in pairs(data.raw[off_grid_type]) do
		prototype.flags = prototype.flags and prototype.flags or {}
		table.insert(prototype.flags, "placeable-off-grid")
	end
end
