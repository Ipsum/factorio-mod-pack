data:extend{
    {
        type = "bool-setting",
        name = "start-with-unit-remote-control",
        setting_type = "startup",
        default_value = true,
    }
}
