--luacheck: no global
data:extend{
    struct_animated_disconnected("unit-scan"),
    struct_animated_disconnected("unitdata-scan"),
    struct_static_connected("unit-control"),
    struct_static_connected("unitdata-control"),
}
