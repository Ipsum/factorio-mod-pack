-- make seperate sound effect (invisible) explosions for fake guns
function add_sound (name, sound)
	data:extend({
		{
			type = "explosion",
			name = name,
			flags = {"not-on-map", "placeable-off-grid"},
			sound = {
				aggregation = { max_count = 1, remove = true },
				variations = sound,
			},
			animations = {
				{
					filename = "__detached-gun-sounds__/blank.png",
					priority = "low",
					width = 1,
					height = 1,
					frame_count = 1,
					animation_speed = 1,
					shift = {0, 0}
				},
			},
		}
	})
end

for _, gun in pairs(data.raw["gun"]) do 
	if gun.attack_parameters.sound then
		local sound = gun.attack_parameters.sound.filename and {gun.attack_parameters.sound} or gun.attack_parameters.sound
		add_sound("gunsound-"..gun.name, sound)
	end
	
	if gun.attack_parameters.cyclic_sound then
		if gun.attack_parameters.cyclic_sound.begin_sound then 
			add_sound("gunsound-"..gun.name.."-begin_sound", gun.attack_parameters.cyclic_sound.begin_sound)
		end
		if gun.attack_parameters.cyclic_sound.middle_sound then 
			add_sound("gunsound-"..gun.name.."-middle_sound", gun.attack_parameters.cyclic_sound.middle_sound)
		end
		if gun.attack_parameters.cyclic_sound.end_sound then 
			add_sound("gunsound-"..gun.name.."-end_sound", gun.attack_parameters.cyclic_sound.end_sound)
		end
	end
end
