function fillDyWorldConfig()
	
	config["gold-ore"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=10, max=20},
		min_amount = 400,
	}
	
	config["silver-ore"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=10, max=20},
		min_amount = 500,
	}
	
	config["lead-ore"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=1},
		richness=14000,
		size={min=10, max=20},
		min_amount = 500,
		
		starting={richness=4000, size=10, probability=1},
	}
	
	config["tin-ore"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=1},
		richness=18000,
		size={min=10, max=20},
		min_amount = 500,
		
		starting={richness=5000, size=10, probability=1},
	}

	config["chromium-ore"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=10, max=20},
		min_amount = 500,
	}
	
	config["cadmium-ore"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=10, max=20},
		min_amount = 500,
	}
	
	config["tungsten-ore"] = {
		type="resource-ore",
		
		allotment=80,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=10, max=20},
		min_amount = 500,
	}	
end