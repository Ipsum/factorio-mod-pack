data:extend{
    {
        type = "int-setting",
        name = "aai-max-structs-per-tick",
        setting_type = "runtime-global",
        default_value = 0,
        minimum_value = 0,
        maximum_value = 1000,
    }
}
