data.raw["autoplace-control"]["grass"] = nil
data.raw["autoplace-control"]["dirt"] = nil
data.raw["autoplace-control"]["sand"] = nil
data.raw["autoplace-control"]["desert"] = nil


-- disable base rocks
data.raw['simple-entity']['rock-huge'].autoplace = nil
data.raw['simple-entity']['rock-big'].autoplace = nil
data.raw['optimized-decorative']['rock-medium'].autoplace = nil
data.raw['optimized-decorative']['rock-small'] .autoplace= nil
data.raw['optimized-decorative']['rock-tiny'].autoplace = nil
data.raw['simple-entity']['sand-rock-big'].autoplace = nil
data.raw['optimized-decorative']['sand-rock-medium'].autoplace = nil
data.raw['optimized-decorative']['sand-rock-small'].autoplace = nil
data.raw['optimized-decorative']['sand-decal'].autoplace = nil
data.raw['optimized-decorative']['sand-dune-decal'].autoplace = nil
data.raw['optimized-decorative']['light-mud-decal'].autoplace = nil
data.raw['optimized-decorative']['red-desert-decal'].autoplace = nil
