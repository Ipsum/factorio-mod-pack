-- debug_status = 1
debug_mod_name = "Zoom"
debug_file = debug_mod_name .. "-debug.txt"
require("utils")

local zoom_factor = 1.5
local zoom_wide_max = 0.01
local zoom_wide_hotkey = 1 / (zoom_factor^7)
local zoom_close_max = 16.00

--------------------------------------------------------------------------------------
local function init_globals()
	-- initialize or update general globals of the mod
	debug_print( "init_globals " )
	
	global.ticks = global.ticks or 0
	global.force_mem = global.force_mem or {}
	global.player_mem = global.player_mem or {}
end

--------------------------------------------------------------------------------------
local function init_player(player)
	if global.player_mem == nil then return end
	
	-- initialize or update per player globals of the mod, and reset the gui
	debug_print( "init_player ", player.name, " connected=", player.connected )
	
	global.player_mem[player.index] = global.player_mem[player.index] or {}
	
	local player_mem = global.player_mem[player.index]
	player_mem.player = player_mem.player or player
	player_mem.zoom = player_mem.zoom or 1
	
	if player.connected then
		build_bar(player)
	end
end

--------------------------------------------------------------------------------------
local function init_players()
	for _, player in pairs(game.players) do
		init_player(player)
	end
end

--------------------------------------------------------------------------------------
local function on_init() 
	-- called once, the first time the mod is loaded on a game (new or existing game)
	debug_print( "on_init" )
	init_globals()
	init_players()
end

script.on_init(on_init)

--------------------------------------------------------------------------------------
local function on_configuration_changed(data)
	-- detect any mod or game version change
	if data.mod_changes ~= nil then
		local changes = data.mod_changes[debug_mod_name]
		if changes ~= nil then
			debug_print( "update mod: ", debug_mod_name, " ", tostring(changes.old_version), " to ", tostring(changes.new_version) )
		
			init_globals()
			init_players()
			
			if changes.old_version and older_version(changes.old_version, "1.0.4") then
				message_all("Zoom: you can now use ALT-Z to directly zoom out wide !")
			end
		
		end
	end
end

script.on_configuration_changed(on_configuration_changed)

--------------------------------------------------------------------------------------
local function on_player_created(event)
	-- called at player creation
	local player = game.players[event.player_index]
	debug_print( "player created ", player.name )
	
	init_player(player)
end

script.on_event(defines.events.on_player_created, on_player_created )

--------------------------------------------------------------------------------------
local function on_player_joined_game(event)
	-- called in SP(once) and MP(at every connect), eventually after on_player_created
	local player = game.players[event.player_index]
	debug_print( "player joined ", player.name )
	
	init_player(player)
end

script.on_event(defines.events.on_player_joined_game, on_player_joined_game )

--------------------------------------------------------------------------------------
local function on_gui_click(event)
	local player = game.players[event.player_index]
	local event_name = event.element.name
	local prefix = string.sub(event_name,1,14)
	local suffix = string.sub(event_name,15)
	
	debug_print( "on_gui_click ", player.name, " ", event_name )

	if event_name == "but_zoom_zin" then
		local player_mem = global.player_mem[player.index]
		if player_mem.zoom < zoom_close_max then 
			player_mem.zoom = player_mem.zoom * zoom_factor
			player.zoom = player_mem.zoom
		end
		
	elseif event_name == "but_zoom_zout" then
		local player_mem = global.player_mem[player.index]
		if player_mem.zoom > zoom_wide_max then 
			player_mem.zoom = player_mem.zoom / zoom_factor
			player.zoom = player_mem.zoom
		end
	end
end

script.on_event(defines.events.on_gui_click, on_gui_click)

--------------------------------------------------------------------------------------
local function on_zoom_hotkey(event)
	local player = game.players[event.player_index]
	local player_mem = global.player_mem[player.index]
	player_mem.zoom = zoom_wide_hotkey
	player.zoom = player_mem.zoom
end

script.on_event("zoom_hotkey", on_zoom_hotkey)

--------------------------------------------------------------------------------------
function build_bar( player )
	-- here only build gui, but not try to update it with player data that is not always already available (in init_player for example)
	local guif = player.gui.top.flw_zoom
	
	if guif == nil then
		debug_print("create gui player" .. player.name)
		guif = player.gui.top.add({type = "flow", name = "flw_zoom", direction = "horizontal", style = "zoom_flow_style"})
		guif.add({type = "sprite-button", name = "but_zoom_zout", sprite = "sprite_zout", style = "zoom_sprite_style"})				
		guif.add({type = "sprite-button", name = "but_zoom_zin", sprite = "sprite_zin", style = "zoom_sprite_style"})				
	end
end
	
--------------------------------------------------------------------------------------
local interface = {}

function interface.reset()
	debug_print( "reset" )
	
	for _, player in pairs(game.players) do
		if player.gui.top.flw_zoom then player.gui.top.flw_zoom.destroy() end
		init_player(player)
	end
end

remote.add_interface( "zoom", interface )

-- /c remote.call( "zoom", "reset" )

