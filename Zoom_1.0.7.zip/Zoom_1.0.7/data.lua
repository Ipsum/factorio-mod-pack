require("utils")
require("prototypes/styles")

data:extend(
	{
		{
			type = "custom-input",
			name = "zoom_hotkey",
			key_sequence = "ALT + Z",
			consuming = "script-only"
		},
	}
)
