data:extend{
    {
      type = "ammo-category",
      name = "electro-bolter"
    },
    {
      type = "damage-type",
      name = "repair"
      -- usually applies negative damage
      -- biological units should get 100% resistance
    },
}
