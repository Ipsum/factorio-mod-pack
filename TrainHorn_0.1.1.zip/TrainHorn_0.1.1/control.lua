script.on_event(defines.events.on_player_died, function(event)
    if event.cause ~= nil then
        if event.cause.type == 'locomotive' then
            event.cause.surface.create_entity(
                {name = "train-horn-sound", position = event.cause.position})
        end
    end
end)

