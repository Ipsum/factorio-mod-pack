---------------- Event Listeners --------------
initialized = false
script.on_event(defines.events.on_tick, function(event)
    if event.tick%60 == 47 then
		if global.slots == nil then
			global.scanners = {}
			global.blueprints = {}
			global.slots = {}
		end
		
		if initialized == false then
			initializeRawData()
			initialized = true
		end

		onUpdate()
    end
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
	if event.created_entity.name == 'blueprint-scanner' then		
		scannerPlaced(event.created_entity)
	end
end)

script.on_event(defines.events.on_built_entity, function(event)
	if event.created_entity.name == 'blueprint-scanner' then
		scannerPlaced(event.created_entity)
	end
end)

script.on_event(defines.events.on_preplayer_mined_item, function(event)
	if event.entity.name == 'blueprint-scanner' then
		scannerRemoved(event.entity)
	elseif event.entity.name == 'blueprint-scanner-chest' then
		slotRemoved(event.entity)	
	end
end)

script.on_event(defines.events.on_robot_pre_mined, function(event)
	if event.entity.name == 'blueprint-scanner' then
		scannerRemoved(event.entity)
	elseif event.entity.name == 'blueprint-scanner-chest' then
		slotRemoved(event.entity)	
	end
end)

script.on_event(defines.events.on_entity_died, function(event)
	if event.entity.name == 'blueprint-scanner' then
		scannerRemoved(event.entity)
	elseif event.entity.name == 'blueprint-scanner-chest' then
		slotRemoved(event.entity)	
	end
end)

---------------- Helper --------------
function findIndex(list, needle)
	ind = -1
	for k,v in pairs(list) do
		if v == needle then
			ind = k
			break
		end
	end	
	return ind
end

function removeFromLists(ind)	
	global.scanners[ind] = nil
	global.slots[ind] = nil
	global.blueprints[ind] = nil
end

function blueprintHash(blueprint)
	str = ""
	if blueprint.get_blueprint_entities() ~= nil then
		for pos, nEntity in pairs(blueprint.get_blueprint_entities()) do
			str = str .. nEntity.name
		end
	end

	if blueprint.get_blueprint_tiles() ~= nil then
		for pos, nEntity in pairs(blueprint.get_blueprint_tiles()) do
			str = str .. nEntity.name
		end
	end

	
	return str	
end

function initializeRawData()
	--game.print(remote.call("data-raw", "prototype", "item", "rail"))
end

---------------- Actual Mod Logic --------------

function scannerRemoved(entity)
	--game.print("Scanner removed.")
	
	-- Find index
	ind = findIndex(global.scanners, entity)
	
	-- Destroy slot entity
	if global.slots[ind] ~= nil then
		global.slots[ind].destroy()
	end
	
	-- Remove from lists
	removeFromLists(ind)
end

function slotRemoved(entity)
	--game.print("Scanner removed.")
	
	-- Find index
	ind = findIndex(global.slots, entity)
	
	-- Destroy scanner entity
	if global.scanners[ind] ~= nil then
		global.scanners[ind].destroy()
	end
	
	-- Remove from lists
	removeFromLists(ind)
end


function scannerPlaced(entity)      
	--game.print("Scanner placed.")	
	
	slot = entity.surface.create_entity{name="blueprint-scanner-chest", force=entity.force, position=entity.position}	
	
	global.scanners[#global.scanners+1] = entity
	global.slots[#global.slots+1] = slot
end

function onUpdate()
	for i, slot in pairs(global.slots) do
		checkSlotUpdate(i, slot)
	end	
end

function checkSlotUpdate(i, slot)
	inventory = slot.get_inventory(defines.inventory.chest)		
	if inventory.find_item_stack("blueprint") == nil and global.blueprints[i] ~= nil then
		--game.print("Blueprint removed")
		global.blueprints[i] = nil
		blueprintRemoved(i)
	elseif inventory.find_item_stack("blueprint") ~= nil and global.blueprints[i] == nil then
		--game.print("Blueprint added")			
		global.blueprints[i] = blueprintHash(inventory.find_item_stack("blueprint"))
		blueprintChanged(i, inventory.find_item_stack("blueprint"))
	elseif global.blueprints[i] ~= nil and global.blueprints[i] ~= blueprintHash(inventory.find_item_stack("blueprint")) then
		--game.print("Blueprint exchanged")
		global.blueprints[i] = blueprintHash(inventory.find_item_stack("blueprint"))
		blueprintChanged(i, inventory.find_item_stack("blueprint"))
	end		
end

function entityToItem(entityName)	
	-- Look for an item or tile
	items = remote.call("data-raw", "prototypes_of_type", "item")	
	for key, item in pairs(items) do
		if item.place_result == entityName then
			return {name = key, count = 1}
		end
		
		if item.place_as_tile ~= nil then
			if item.place_as_tile.result == entityName then
				return {name = key, count = 1}
			end
		end
	end	 
	
	-- Look for a rail-planner
	items = remote.call("data-raw", "prototypes_of_type", "rail-planner")	
	for key, item in pairs(items) do
		if item.straight_rail == entityName then
			return {name = key, count = 1}
		elseif item.curved_rail == entityName then
			return {name = key, count = 4}
		end
	end	 
	
	game.print("Unable to identify item for entity "..entityName)
	return nil
end

-- Stops sending blueprint content
function blueprintRemoved(i)		
	control = global.scanners[i].get_or_create_control_behavior()
	control.parameters = 
	{
        parameters = {}
	}	
end

-- Send blueprint content to the circuit network
function blueprintChanged(i, blueprint)
	entities = blueprint.get_blueprint_entities()
	tiles = blueprint.get_blueprint_tiles()
	control = global.scanners[i].get_or_create_control_behavior()
	
	-- Merge equal entities
	list = {}		
	if entities ~= nil then
		for i, entry in pairs(entities) do
			infos = entityToItem(entry.name)
			if list[infos.name] == nil then
				list[infos.name] = infos.count
			else
				list[infos.name] = list[infos.name] + infos.count
			end
		end
	end
	-- and tiles
	if tiles ~= nil then
		for i, entry in pairs(tiles) do
			infos = entityToItem(entry.name)
			if list[infos.name] == nil then
				list[infos.name] = infos.count
			else
				list[infos.name] = list[infos.name] + infos.count
			end
		end
	end

	
	-- Set combinator Parameters
	params = {}
	for name, count in pairs(list) do				
		params[#params+1] = {signal = {type = "item", name = name}, count = count, index = #params+1}				
	end	 
	
	control.parameters = 
	{
        parameters = params
	}
end